class Dni:
    pass
