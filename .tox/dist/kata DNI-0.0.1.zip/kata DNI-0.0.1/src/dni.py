class Dni: 
    pass
