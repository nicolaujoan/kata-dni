class Tabla_asignacion:
    pass
