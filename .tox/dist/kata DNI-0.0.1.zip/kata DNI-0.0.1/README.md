# kata-dni
## practicando SRP, OCP y POO usando python
